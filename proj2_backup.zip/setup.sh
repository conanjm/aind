#!/bin/bash

echo "Download your JWT here:"
echo
echo "    https://project-assistant.udacity.com/auth_tokens/new"
echo
echo "Once you've downloaded your JWT, copy the contents into the editor tab titled 'jwt'"
echo "After that step, you can run project assistant by running 'udacity submit' from the terminal"
